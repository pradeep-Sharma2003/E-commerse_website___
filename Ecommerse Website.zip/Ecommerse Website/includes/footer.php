<footer>
<div class="footer bg-info p-3 mt-5 text-center">
      <p>All right reserved @- Designed by Pradeep-2023</p>
</div>
</footer>